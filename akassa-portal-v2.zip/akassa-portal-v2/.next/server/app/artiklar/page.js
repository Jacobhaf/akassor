(()=>{var e={};e.id=431,e.ids=[431],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},8943:(e,a,t)=>{"use strict";t.r(a),t.d(a,{GlobalError:()=>i.a,__next_app__:()=>m,originalPathname:()=>g,pages:()=>x,routeModule:()=>p,tree:()=>o}),t(7145),t(8702),t(5866);var r=t(3191),s=t(8716),n=t(7922),i=t.n(n),l=t(5231),d={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>l[e]);t.d(a,d);let o=["",{children:["artiklar",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,7145)),"/Users/jacobhafstrom25/.gemini/antigravity/playground/blazing-eclipse/akassa-portal-v2/src/app/artiklar/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,8702)),"/Users/jacobhafstrom25/.gemini/antigravity/playground/blazing-eclipse/akassa-portal-v2/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,5866,23)),"next/dist/client/components/not-found-error"]}],x=["/Users/jacobhafstrom25/.gemini/antigravity/playground/blazing-eclipse/akassa-portal-v2/src/app/artiklar/page.tsx"],g="/artiklar/page",m={require:t,loadChunk:()=>Promise.resolve()},p=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/artiklar/page",pathname:"/artiklar",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:o}})},4251:(e,a,t)=>{Promise.resolve().then(t.t.bind(t,9404,23))},7145:(e,a,t)=>{"use strict";t.r(a),t.d(a,{default:()=>l,metadata:()=>i});var r=t(9510),s=t(7371),n=t(9857);let i={title:"Artiklar om a-kassa | V\xe4lj a-kassa",description:"L\xe4s v\xe5ra guider och artiklar om a-kassa, ers\xe4ttning och trygghet p\xe5 arbetsmarknaden."};function l(){return r.jsx("div",{className:"bg-white py-16 sm:py-24",children:(0,r.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,r.jsxs)("div",{className:"mx-auto max-w-2xl text-center",children:[r.jsx("h1",{className:"text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl",children:"Artiklar & Guider"}),r.jsx("p",{className:"mt-2 text-lg leading-8 text-gray-600",children:"Allt du beh\xf6ver veta om a-kassa, ers\xe4ttning och din trygghet."})]}),r.jsx("div",{className:"mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3",children:n.D.map(e=>(0,r.jsxs)("article",{className:"flex flex-col items-start justify-between",children:[(0,r.jsxs)("div",{className:"relative w-full",children:[r.jsx("div",{className:"aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2] overflow-hidden relative",children:r.jsx("div",{className:"absolute inset-0 bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center text-blue-300",children:r.jsx("svg",{className:"w-12 h-12",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:r.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:1,d:"M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"})})})}),r.jsx("div",{className:"absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"})]}),(0,r.jsxs)("div",{className:"max-w-xl",children:[(0,r.jsxs)("div",{className:"mt-8 flex items-center gap-x-4 text-xs",children:[r.jsx("time",{dateTime:e.publishedAt,className:"text-gray-500",children:e.publishedAt}),r.jsx("span",{className:"relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100",children:"Guide"})]}),(0,r.jsxs)("div",{className:"group relative",children:[r.jsx("h3",{className:"mt-3 text-lg font-semibold leading-6 text-gray-900 group-hover:text-gray-600",children:(0,r.jsxs)(s.default,{href:`/artiklar/${e.slug}`,children:[r.jsx("span",{className:"absolute inset-0"}),e.title]})}),r.jsx("p",{className:"mt-5 line-clamp-3 text-sm leading-6 text-gray-600",children:e.summary})]})]})]},e.slug))})]})})}},9857:(e,a,t)=>{"use strict";t.d(a,{D:()=>r});let r=[{slug:"vad-ar-akassa",title:"Vad \xe4r a-kassa och hur fungerar den?",summary:"En grundl\xe4ggande guide om arbetsl\xf6shetsf\xf6rs\xe4kringen, vem som kan g\xe5 med och hur du f\xe5r ers\xe4ttning.",image:"/artiklar/akassa-grundguide.jpg",publishedAt:"2023-11-15",content:`
      <h2>Vad \xe4r en a-kassa?</h2>
      <p>A-kassa st\xe5r f\xf6r arbetsl\xf6shetskassa. Det \xe4r en f\xf6rs\xe4kring som ger dig ekonomisk trygghet om du skulle bli arbetsl\xf6s. I Sverige \xe4r a-kassan statsst\xf6dd men drivs av olika f\xf6reningar, ofta kopplade till fackf\xf6rbund.</p>
      
      <h2>Vem kan g\xe5 med?</h2>
      <p>De flesta a-kassor \xe4r \xf6ppna f\xf6r specifika yrkesgrupper, men det finns ocks\xe5 a-kassor som \xe4r \xf6ppna f\xf6r alla, till exempel Alfa-kassan. F\xf6r att bli medlem m\xe5ste du oftast ha arbetat en viss tid i Sverige.</p>
      
      <h2>Hur f\xe5r jag ers\xe4ttning?</h2>
      <p>F\xf6r att f\xe5 ers\xe4ttning m\xe5ste du uppfylla arbetsvillkoret och medlemsvillkoret. Det inneb\xe4r oftast att du ska ha varit medlem i minst 12 m\xe5nader och arbetat en viss m\xe4ngd timmar under det senaste \xe5ret.</p>
    `},{slug:"vilken-akassa-passar-mig",title:"Vilken a-kassa passar olika yrken?",summary:"Hitta r\xe4tt a-kassa baserat p\xe5 din bransch. Vi listar de vanligaste a-kassorna f\xf6r olika yrkesgrupper.",image:"/artiklar/valja-ratt-akassa.jpg",publishedAt:"2023-11-20",content:`
      <h2>Hitta r\xe4tt i djungeln</h2>
      <p>Det finns \xf6ver 20 olika a-kassor i Sverige. Vissa \xe4r specialiserade p\xe5 akademiker, andra p\xe5 byggnadsarbetare, och vissa p\xe5 egenf\xf6retagare.</p>
      
      <h3>Akademikernas a-kassa</h3>
      <p>Passar dig som har en h\xf6gskoleutbildning eller studerar. Det \xe4r Sveriges st\xf6rsta a-kassa.</p>
      
      <h3>Unionens a-kassa</h3>
      <p>F\xf6r dig som \xe4r tj\xe4nsteman i privat sektor. En av de st\xf6rsta och mest popul\xe4ra a-kassorna.</p>
      
      <h3>Sm\xe5f\xf6retagarnas a-kassa</h3>
      <p>Specialiserad f\xf6r dig som driver eget f\xf6retag eller \xe4r f\xf6retagsledare.</p>
    `},{slug:"ersattning-karens-villkor",title:"S\xe5 h\xe4r funkar ers\xe4ttning, karens och medlemsvillkor",summary:"Vi reder ut begreppen kring dagpenning, karensdagar och vad som kr\xe4vs f\xf6r att f\xe5 full ers\xe4ttning.",image:"/artiklar/ersattning-karens-villkor.jpg",publishedAt:"2023-11-25",content:`
      <h2>Hur mycket f\xe5r jag?</h2>
      <p>Ers\xe4ttningen baseras p\xe5 din tidigare inkomst. Taket f\xf6r ers\xe4ttningen h\xf6jdes under pandemin och ligger kvar p\xe5 en h\xf6gre niv\xe5. Som mest kan du f\xe5 ca 80% av din l\xf6n upp till ett visst tak.</p>
      
      <h2>Karensdagar</h2>
      <p>N\xe4r du blir arbetsl\xf6s har du oftast n\xe5gra karensdagar i b\xf6rjan d\xe5 du inte f\xe5r n\xe5gon ers\xe4ttning. Detta fungerar som en sj\xe4lvrisk.</p>
      
      <h2>Medlemsvillkoret</h2>
      <p>F\xf6r att f\xe5 inkomstbaserad ers\xe4ttning m\xe5ste du ha varit medlem i a-kassan i minst 12 sammanh\xe4ngande m\xe5nader.</p>
    `},{slug:"vanliga-misstag",title:"Vanliga misstag kring a-kassa och anst\xe4llningsformer",summary:"Missar du att byta a-kassa n\xe4r du byter bransch? Eller gl\xf6mmer du att anm\xe4la dig till Arbetsf\xf6rmedlingen? H\xe4r \xe4r f\xe4llorna att undvika.",image:"/artiklar/vanliga-misstag.jpg",publishedAt:"2023-11-30",content:`
      <h2>1. Gl\xf6mma att anm\xe4la sig till Arbetsf\xf6rmedlingen</h2>
      <p>Detta \xe4r det absolut vanligaste misstaget. Du m\xe5ste skriva in dig p\xe5 Arbetsf\xf6rmedlingen din <strong>f\xf6rsta</strong> arbetsl\xf6sa dag f\xf6r att f\xe5 ers\xe4ttning.</p>
      
      <h2>2. Glapp i medlemskapet</h2>
      <p>Om du byter a-kassa, se till att det inte blir n\xe5got glapp. Beg\xe4r uttr\xe4de och intr\xe4de i direkt anslutning till varandra.</p>
      
      <h2>3. Inte skicka in tidrapporter i tid</h2>
      <p>F\xf6r att f\xe5 ut dina pengar m\xe5ste du kassakort (tidrapporter) skickas in l\xf6pande. Slarv med detta leder till f\xf6rsenad utbetalning.</p>
    `},{slug:"ekonomi-kris-akassa",title:"N\xe4r ekonomin rasar efter jobbf\xf6rlust – d\xe4rf\xf6r \xe4r a-kassan s\xe5 viktig",summary:"Att f\xf6rlora jobbet kan vara en ekonomisk chock. A-kassan \xe4r ditt f\xf6rsta skyddsn\xe4t, men ibland r\xe4cker det inte till. S\xe5 h\xe4r hanterar du en ekonomisk kris.",image:"/artiklar/ekonomi-jobbforlust.jpg",publishedAt:"2023-12-05",content:`
      <h2>En ekonomisk chock</h2>
      <p>Att bli av med jobbet inneb\xe4r ofta att inkomsten halveras eller f\xf6rsvinner helt under en period. Utan a-kassa st\xe5r m\xe5nga helt utan skyddsn\xe4t och tvingas leva p\xe5 besparingar eller f\xf6rs\xf6rjningsst\xf6d.</p>
      
      <h2>A-kassan som krockkudde</h2>
      <p>A-kassan \xe4r till f\xf6r att ge dig tid att st\xe4lla om. Den t\xe4cker en del av inkomstbortfallet och ger dig m\xf6jlighet att s\xf6ka nya jobb utan att beh\xf6va s\xe4lja hus och hem direkt.</p>
      
      <h2>Om krisen \xe4nd\xe5 \xe4r framme</h2>
      <p>Ibland r\xe4cker inte a-kassan till, eller s\xe5 har man dragit p\xe5 sig kostnader som \xe4r sv\xe5ra att hantera med en l\xe4gre inkomst. Obetalda r\xe4kningar kan snabbt v\xe4xa till stora skulder hos Kronofogden.</p>
      
      <div class="bg-red-50 border-l-4 border-red-500 p-4 my-6">
        <h3 class="text-red-800 font-bold text-lg mb-2">Har du hamnat i ekonomisk knipa?</h3>
        <p class="text-red-700 mb-4">
          Om du har sv\xe5rt att betala dina skulder eller k\xe4nner att ekonomin h\xe5ller p\xe5 att krascha, v\xe4nta inte med att s\xf6ka hj\xe4lp. Ju tidigare du agerar, desto st\xf6rre chans har du att v\xe4nda situationen.
        </p>
        <a 
          href="https://skuldregistret.se/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-block bg-red-600 text-white font-bold py-2 px-4 rounded hover:bg-red-700 transition-colors"
        >
          F\xe5 hj\xe4lp hos Skuldregistret.se &rarr;
        </a>
      </div>
      
      <p>Kom ih\xe5g att du inte \xe4r ensam. M\xe5nga hamnar i ekonomiska sv\xe5righeter n\xe5gon g\xe5ng i livet. Det viktiga \xe4r att ta tag i problemen och inte stoppa huvudet i sanden.</p>
    `}]}};var a=require("../../webpack-runtime.js");a.C(e);var t=e=>a(a.s=e),r=a.X(0,[948,354,233],()=>t(8943));module.exports=r})();